<?php
/**
 * Основные параметры WordPress.
 *
 * Этот файл содержит следующие параметры: настройки MySQL, префикс таблиц,
 * секретные ключи, язык WordPress и ABSPATH. Дополнительную информацию можно найти
 * на странице {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Кодекса. Настройки MySQL можно узнать у хостинг-провайдера.
 *
 * Этот файл используется сценарием создания wp-config.php в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать этот файл
 * с именем "wp-config.php" и заполнить значения.
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'oof_listoofby');

/** Имя пользователя MySQL */
define('DB_USER', 'oof_listoofby');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', 'oof_listoofby');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется снова авторизоваться.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ']v L!ZJdCu?JQ6HZ6(.3J!GzThucf!|X9$G||rX}pgJFr>$T6N7k)wU`-SqD71{0');
define('SECURE_AUTH_KEY',  'j|}YH%{y@Fjkp*gxF++g7rI{hg/kuUZ->[mh*DxA2l?NE5- ;7]!ZS-a$[p>|E6w');
define('LOGGED_IN_KEY',    'v&^AdXHaN:41w`Kb7`$eO04mZG(Y}z-Z$OrQ<ubTSdR[q}kUlV1NZ~P-/XF+0~vZ');
define('NONCE_KEY',        ']--9 2D1]b*=><UNlUZHeDM;/P~~zX-xnXoUj2)4)jW`t}mw#XBoWC2[v-O1=3k^');
define('AUTH_SALT',        'pM<qfay{}E-r,u$;a}k$>zvjB$^]yG(j39B|FCSbDQYd7|K[BgW9+5;MK-C#_0(9');
define('SECURE_AUTH_SALT', '|VDOpkAorr?c>4o?dxMn?SG[nz+v9hZx1Dwj~~:p)E0l#<e`a-Wu2pFLe7%B!9_}');
define('LOGGED_IN_SALT',   '4/I]|0x_ONLUyub8|^>+;E[?uML_2g0t/<(|hpXQy-g`P0zE{4{PTSwpn|p+XFuc');
define('NONCE_SALT',       'EE;XXW6W?= 4-?N_ ITy+-sW!]r`g+ZYT@F. .G.iJoI.;&0[MYh<Sj.SuH`Vox2');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько блогов в одну базу данных, если вы будете использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Язык локализации WordPress, по умолчанию английский.
 *
 * Измените этот параметр, чтобы настроить локализацию. Соответствующий MO-файл
 * для выбранного языка должен быть установлен в wp-content/languages. Например,
 * чтобы включить поддержку русского языка, скопируйте ru_RU.mo в wp-content/languages
 * и присвойте WPLANG значение 'ru_RU'.
 */
define('WPLANG', 'ru_RU');

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Настоятельно рекомендуется, чтобы разработчики плагинов и тем использовали WP_DEBUG
 * в своём рабочем окружении.
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */
define('WP_HOME', 'http://promkon.by');
define('WP_SITEURL', 'http://promkon.by');

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
